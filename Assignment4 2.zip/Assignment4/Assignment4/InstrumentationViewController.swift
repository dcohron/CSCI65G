//
//  FirstViewController.swift
//  Assignment4
//
//  Created by David Cohron on 7/13/16.
//  Copyright © 2016 Trident Advisors. All rights reserved.
//

import UIKit

class InstrumentationViewController: UIViewController {

    @IBOutlet weak var rowBox: UITextField!
    
    @IBOutlet weak var colBox: UITextField!
  
    @IBAction func rowStepperChanged(sender: UIStepper) {
        rowBox.text = String(Int(sender.value))
        currentGrid.rows = Int(sender.value)
    }
    
    @IBAction func colStepperChanged(sender: UIStepper) {
        colBox.text = String(Int(sender.value))
        currentGrid.cols = Int(sender.value)
    }
    
    @IBAction func refreshSliderChanged(sender: UISlider) {
        currentGrid.refreshRate = Int(sender.value)
    }
    
    @IBAction func refreshSwitchChanged(sender: UISwitch) {
        currentGrid.refreshTimer = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // set title for navigation bar
        self.navigationItem.title = "Instrumentation";
        
        // Modify the display title on the tab bar
        self.tabBarItem.title = "Instrumentation";
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func currentGrid(currentGrid: StandardEngine, didUpdateRows modelRows: Int) {
        rowBox.text = String(modelRows)
    }
    
    func currentGrid(currentGrid: StandardEngine, didUpdateColumns modelColumns: Int) {
        colBox.text = String(modelColumns)
    }

}

