//
//  StatisticsViewController.swift
//  Assignment4
//
//  Created by David Cohron on 7/13/16.
//  Copyright © 2016 Trident Advisors. All rights reserved.
//

import UIKit

class StatisticsViewController: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
