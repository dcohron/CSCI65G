//
//  App.swift
//  TopApps
//
//  Created by Attila on 2015. 11. 10..
//  Copyright © 2015. -. All rights reserved.
//

import Foundation

public struct App {
  
  public let name: String
  public let link: String
  
  public init(name: String, link: String) {
    self.name = name
    self.link = link
  }
  
}
